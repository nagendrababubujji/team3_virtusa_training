package com.pack;

public class AccountRepositoryTests {

}
